import { Action } from "overmind";

//export const globalConfig: Action = async ({ state, actions }) => {};
