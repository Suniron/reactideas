export interface State {
  user: firebase.User | null;
}

export const state: State = {
  user: null
};
